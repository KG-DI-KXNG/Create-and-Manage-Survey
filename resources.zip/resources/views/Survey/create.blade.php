<h1>Create your survey here</h1><br>
<a href="{{route('survey.createdemo')}}">Create Demo Survey</a><br>
<a href="{{route('survey.testing')}}">test Demo Survey</a>